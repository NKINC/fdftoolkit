For (VB.NET) & (C#) FDFToolkit.net Examples, and FDFToolkit.net Syntax Help File see release page.

Compile and reference both iTextSharp.dll & FDFApp.dll inside your Visual Studio .Net projects.